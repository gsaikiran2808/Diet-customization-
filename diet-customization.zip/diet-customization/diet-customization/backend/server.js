
const express = require('express');
const bodyParser = require('body-parser');
const cors = require('cors');

const app = express();
app.use(cors());
app.use(bodyParser.json());

let mealCategories = [
    { id: 1, name: 'Breakfast', recipes: [] },
    { id: 2, name: 'Lunch', recipes: [] },
    { id: 3, name: 'Dinner', recipes: [] },
    { id: 4, name: 'Snack', recipes: [] },
    { id: 5, name: 'Post-Workout', recipes: [] }
];

// Get meal categories
app.get('/api/meals', (req, res) => {
    res.json(mealCategories);
});

// Add new meal category
app.post('/api/meals', (req, res) => {
    const newMeal = { id: Date.now(), name: req.body.name, recipes: [] };
    mealCategories.push(newMeal);
    res.json(newMeal);
});

// Add new recipe to meal
app.post('/api/meals/:id/recipes', (req, res) => {
    const meal = mealCategories.find(m => m.id == req.params.id);
    if (meal) {
        meal.recipes.push(req.body.recipe);
        res.json(meal);
    } else {
        res.status(404).send('Meal not found');
    }
});

// Start server
const PORT = process.env.PORT || 5000;
app.listen(PORT, () => console.log(`Server running on port ${PORT}`));
