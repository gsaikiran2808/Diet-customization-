
import React, { useState, useEffect } from 'react';
import axios from 'axios';

function App() {
  const [meals, setMeals] = useState([]);
  const [newMealName, setNewMealName] = useState('');

  useEffect(() => {
    axios.get('http://localhost:5000/api/meals')
      .then(response => {
        setMeals(response.data);
      })
      .catch(error => {
        console.error('Error fetching meals:', error);
      });
  }, []);

  const addNewMealCategory = () => {
    axios.post('http://localhost:5000/api/meals', { name: newMealName })
      .then(response => {
        setMeals([...meals, response.data]);
        setNewMealName('');
      })
      .catch(error => {
        console.error('Error adding meal category:', error);
      });
  };

  const addRecipeToMeal = (mealId, recipe) => {
    axios.post(`http://localhost:5000/api/meals/${mealId}/recipes`, { recipe })
      .then(response => {
        setMeals(meals.map(meal => meal.id === mealId ? response.data : meal));
      })
      .catch(error => {
        console.error('Error adding recipe:', error);
      });
  };

  return (
    <div className="App">
      <header>
        <h1>Diet Customization Page</h1>
        <input
          type="text"
          placeholder="New Meal Category"
          value={newMealName}
          onChange={(e) => setNewMealName(e.target.value)}
        />
        <button onClick={addNewMealCategory}>Add New Meal Category</button>
      </header>
      <div id="meal-management">
        {meals.map(meal => (
          <div key={meal.id} className="meal">
            <h2>{meal.name}</h2>
            <button onClick={() => addRecipeToMeal(meal.id, 'New Recipe')}>Add New Recipe</button>
            <ul>
              {meal.recipes.map((recipe, index) => (
                <li key={index}>{recipe}</li>
              ))}
            </ul>
          </div>
        ))}
      </div>
    </div>
  );
}

export default App;
